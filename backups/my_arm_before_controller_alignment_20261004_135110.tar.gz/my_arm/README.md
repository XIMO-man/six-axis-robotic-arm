# 六轴机械臂与双指夹爪

ROS 2 Jazzy / Gazebo Harmonic。包名为 `my_arm01`。

```bash
source /opt/ros/jazzy/setup.bash
cd /root/catkin_ws
colcon build --packages-select my_arm01 --symlink-install
source install/setup.bash
ros2 launch my_arm01 gazebo.launch.py
```

另开终端执行已知场景抓取测试：

```bash
source /opt/ros/jazzy/setup.bash
source /root/catkin_ws/install/setup.bash
ros2 run my_arm01 grasp_demo.py --ros-args -p use_sim_time:=true
```

测试使用关节轨迹和夹爪 action，检查绿色方块实际抬升高度、保持和释放。
不使用吸附或瞬移；此示例仅适用于默认尺寸与默认方块位置，没有通用避障规划。
重新运行前关闭并重启仿真，恢复初始场景。不要同时运行 display.launch.py，
以免人工 joint_states 与仿真反馈冲突。

可选：`gui:=false` 只运行服务器；`rviz:=true` 同时显示 RViz。
`ros2 control list_controllers` 应显示三个 active 控制器。
原 RViz 滑块模式仍可使用 `ros2 launch my_arm01 display.launch.py`。

模型源文件仍位于 `src/six_axis_arm.urdf.xacro`，安装到包共享目录的 `urdf/`。
质量、摩擦和形状都是演示用估算值，后续实机适配需标定。

## 验证记录

2026-10-04：Jazzy / Harmonic 无界面物理仿真测试通过。三个控制器均 active；
方块实测抬升约 0.1000 m，保持 2 秒后放回桌面，脚本输出 PASS。
左右手指在夹持时位置约为 0.01990 m / 0.02010 m。

当前夹爪使用位置控制，`max_effort` 不等同于已实现标定的力控制。
启动日志可能提示物理引擎不支持原生 mimic 约束，本工程由 gz_ros2_control
执行手指联动；以上测试使用的就是这条控制路径。
`GripperActionController` 在当前安装版本有弃用提示，但仍支持本示例的
`control_msgs/action/GripperCommand` 接口。
